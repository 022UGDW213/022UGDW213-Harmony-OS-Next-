export interface CVE {
  id: string;
  publishedDate: string;
  lastModifiedDate: string;
  description: string;
  cvssScore: number;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'NONE';
  vendor: string;
  product: string;
  version: string;
  cweId?: string;
  cweName?: string;
  references: string[];
  status: 'PUBLISHED' | 'RESERVED' | 'REJECTED';
}

export interface BugBountyFinding {
  id: string;
  title: string;
  description: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  vulnerabilityType: string;
  date: string;
  bounty: number;
  program: string;
  status: 'Resolved' | 'Pending' | 'In Progress';
}

export interface CVEStats {
  totalCVEs: number;
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  byYear: Record<number, number>;
  byVendor: Record<string, number>;
}
