import { useState } from 'react';
import { Header } from '@/components/Header';
import { CVEDatabase } from '@/sections/CVEDatabase';
import { BugBounty } from '@/sections/BugBounty';

function App() {
  const [activeTab, setActiveTab] = useState<'cve' | 'bugbounty'>('cve');

  return (
    <div className="min-h-screen bg-black">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'cve' ? <CVEDatabase /> : <BugBounty />}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-gray-500">
              CVE Security Dashboard • Data from NVD Database
            </p>
            <p className="text-sm text-gray-600">
              © 2025 • Covering CVEs from 1999 to 2025
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
