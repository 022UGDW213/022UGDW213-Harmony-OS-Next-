import { Shield, Database, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface HeaderProps {
  activeTab: 'cve' | 'bugbounty';
  onTabChange: (tab: 'cve' | 'bugbounty') => void;
}

export function Header({ activeTab, onTabChange }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-black/80 backdrop-blur-xl border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <button 
              className="lg:hidden p-2 -ml-2 text-gray-400 hover:text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                <Shield className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-white">CVE Security</h1>
                <p className="text-xs text-gray-500 -mt-0.5">Dashboard</p>
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            <button
              onClick={() => onTabChange('cve')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'cve' 
                  ? 'bg-white/10 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              CVE Database
            </button>
            <button
              onClick={() => onTabChange('bugbounty')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'bugbounty' 
                  ? 'bg-white/10 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Bug Bounty
            </button>
          </nav>

          {/* NVD Database Badge */}
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10">
              <Database className="w-4 h-4 text-gray-400" />
              <span className="text-sm text-gray-400">NVD Database</span>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="lg:hidden py-3 border-t border-white/10">
            <button
              onClick={() => {
                onTabChange('cve');
                setMobileMenuOpen(false);
              }}
              className={`w-full px-4 py-3 rounded-lg text-sm font-medium text-left transition-colors ${
                activeTab === 'cve' 
                  ? 'bg-white/10 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              CVE Database
            </button>
            <button
              onClick={() => {
                onTabChange('bugbounty');
                setMobileMenuOpen(false);
              }}
              className={`w-full px-4 py-3 rounded-lg text-sm font-medium text-left transition-colors ${
                activeTab === 'bugbounty' 
                  ? 'bg-white/10 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              Bug Bounty
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
