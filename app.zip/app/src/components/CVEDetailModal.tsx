import { X, Calendar, Building2, Tag, ExternalLink, Shield, AlertTriangle } from 'lucide-react';
import { SeverityBadge } from './SeverityBadge';
import type { CVE } from '@/types/cve';

interface CVEDetailModalProps {
  cve: CVE | null;
  isOpen: boolean;
  onClose: () => void;
}

export function CVEDetailModal({ cve, isOpen, onClose }: CVEDetailModalProps) {
  if (!isOpen || !cve) return null;

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      month: 'long', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div 
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-[#0d1117] border border-white/10 rounded-2xl animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-[#0d1117] border-b border-white/10 p-6 flex items-start justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">{cve.id}</h2>
            <SeverityBadge severity={cve.severity} />
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* CVSS Score */}
          <div className="flex items-center gap-4 p-4 bg-white/5 rounded-xl">
            <div className={`w-16 h-16 rounded-xl flex items-center justify-center ${
              cve.cvssScore >= 9 ? 'bg-red-500/20' :
              cve.cvssScore >= 7 ? 'bg-orange-500/20' :
              cve.cvssScore >= 4 ? 'bg-yellow-500/20' : 'bg-blue-500/20'
            }`}>
              <span className={`text-2xl font-bold ${
                cve.cvssScore >= 9 ? 'text-red-400' :
                cve.cvssScore >= 7 ? 'text-orange-400' :
                cve.cvssScore >= 4 ? 'text-yellow-400' : 'text-blue-400'
              }`}>
                {cve.cvssScore}
              </span>
            </div>
            <div>
              <p className="text-sm text-gray-400">CVSS v3 Score</p>
              <p className={`text-lg font-semibold ${
                cve.cvssScore >= 9 ? 'text-red-400' :
                cve.cvssScore >= 7 ? 'text-orange-400' :
                cve.cvssScore >= 4 ? 'text-yellow-400' : 'text-blue-400'
              }`}>
                {cve.severity}
              </p>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-sm font-medium text-gray-400 mb-2 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Description
            </h3>
            <p className="text-gray-300 leading-relaxed">{cve.description}</p>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-white/5 rounded-xl">
              <div className="flex items-center gap-2 text-gray-400 mb-1">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">Published</span>
              </div>
              <p className="text-white font-medium">{formatDate(cve.publishedDate)}</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl">
              <div className="flex items-center gap-2 text-gray-400 mb-1">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">Last Modified</span>
              </div>
              <p className="text-white font-medium">{formatDate(cve.lastModifiedDate)}</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl">
              <div className="flex items-center gap-2 text-gray-400 mb-1">
                <Building2 className="w-4 h-4" />
                <span className="text-sm">Vendor</span>
              </div>
              <p className="text-white font-medium">{cve.vendor}</p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl">
              <div className="flex items-center gap-2 text-gray-400 mb-1">
                <Shield className="w-4 h-4" />
                <span className="text-sm">Product</span>
              </div>
              <p className="text-white font-medium">{cve.product}</p>
              {cve.version !== 'n/a' && (
                <p className="text-sm text-gray-500">v{cve.version}</p>
              )}
            </div>
          </div>

          {/* CWE */}
          {cve.cweId && (
            <div>
              <h3 className="text-sm font-medium text-gray-400 mb-2 flex items-center gap-2">
                <Tag className="w-4 h-4" />
                Weakness
              </h3>
              <div className="inline-flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg">
                <span className="text-blue-400 font-medium">{cve.cweId}</span>
                {cve.cweName && (
                  <span className="text-gray-400">- {cve.cweName}</span>
                )}
              </div>
            </div>
          )}

          {/* References */}
          {cve.references.length > 0 && (
            <div>
              <h3 className="text-sm font-medium text-gray-400 mb-2 flex items-center gap-2">
                <ExternalLink className="w-4 h-4" />
                References
              </h3>
              <div className="space-y-2">
                {cve.references.map((ref, index) => (
                  <a
                    key={index}
                    href={ref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 p-3 bg-white/5 rounded-lg text-sm text-blue-400 hover:bg-white/10 hover:text-blue-300 transition-colors group"
                  >
                    <ExternalLink className="w-4 h-4 opacity-50 group-hover:opacity-100" />
                    <span className="truncate">{ref}</span>
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Status */}
          <div className="pt-4 border-t border-white/10">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Status</span>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                cve.status === 'PUBLISHED' ? 'bg-green-500/20 text-green-400' :
                cve.status === 'RESERVED' ? 'bg-yellow-500/20 text-yellow-400' :
                'bg-red-500/20 text-red-400'
              }`}>
                {cve.status}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
