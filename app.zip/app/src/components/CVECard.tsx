import { Calendar, Building2, Tag } from 'lucide-react';
import { SeverityBadge } from './SeverityBadge';
import type { CVE } from '@/types/cve';

interface CVECardProps {
  cve: CVE;
  onClick?: () => void;
}

export function CVECard({ cve, onClick }: CVECardProps) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  return (
    <div 
      onClick={onClick}
      className="cve-card bg-[#0d1117] border border-white/10 rounded-xl p-5 cursor-pointer"
    >
      <div className="flex items-start justify-between gap-4 mb-3">
        <h3 className="text-lg font-semibold text-white">{cve.id}</h3>
        <SeverityBadge severity={cve.severity} />
      </div>

      <div className="flex items-center gap-4 text-sm text-gray-400 mb-3">
        <div className="flex items-center gap-1.5">
          <Calendar className="w-4 h-4" />
          <span>{formatDate(cve.publishedDate)}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-gray-500">CVSS:</span>
          <span className={`font-semibold ${
            cve.cvssScore >= 9 ? 'text-red-400' :
            cve.cvssScore >= 7 ? 'text-orange-400' :
            cve.cvssScore >= 4 ? 'text-yellow-400' : 'text-blue-400'
          }`}>
            {cve.cvssScore}
          </span>
        </div>
      </div>

      <p className="text-gray-300 text-sm line-clamp-2 mb-4">
        {cve.description}
      </p>

      <div className="flex items-center justify-between pt-3 border-t border-white/5">
        <div className="flex items-center gap-1.5 text-sm text-gray-400">
          <Building2 className="w-4 h-4" />
          <span>{cve.vendor}</span>
        </div>
        {cve.cweId && (
          <div className="flex items-center gap-1.5 text-sm text-gray-500">
            <Tag className="w-4 h-4" />
            <span>{cve.cweId}</span>
          </div>
        )}
      </div>
    </div>
  );
}
