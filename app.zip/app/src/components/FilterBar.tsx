import { useState } from 'react';
import { ChevronDown, Filter } from 'lucide-react';

interface FilterBarProps {
  selectedSeverity: string | null;
  onSeverityChange: (severity: string | null) => void;
  selectedYear: number | null;
  onYearChange: (year: number | null) => void;
  selectedVendor: string | null;
  onVendorChange: (vendor: string | null) => void;
  years: number[];
  vendors: string[];
}

export function FilterBar({
  selectedSeverity,
  onSeverityChange,
  selectedYear,
  onYearChange,
  selectedVendor,
  onVendorChange,
  years,
  vendors
}: FilterBarProps) {
  const [showFilters, setShowFilters] = useState(false);

  const severities = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];

  const hasActiveFilters = selectedSeverity || selectedYear || selectedVendor;

  const clearFilters = () => {
    onSeverityChange(null);
    onYearChange(null);
    onVendorChange(null);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <button
          onClick={() => setShowFilters(!showFilters)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border transition-colors ${
            showFilters || hasActiveFilters
              ? 'bg-blue-500/10 border-blue-500/30 text-blue-400'
              : 'bg-[#0d1117] border-white/10 text-gray-400 hover:text-white'
          }`}
        >
          <Filter className="w-4 h-4" />
          <span className="text-sm font-medium">Filters</span>
          <ChevronDown className={`w-4 h-4 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
        </button>

        {hasActiveFilters && (
          <button
            onClick={clearFilters}
            className="px-4 py-2.5 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
          >
            Clear all
          </button>
        )}

        {/* Active filter pills */}
        <div className="hidden sm:flex items-center gap-2">
          {selectedSeverity && (
            <span className="px-3 py-1.5 rounded-full text-xs font-medium bg-blue-500/20 text-blue-400 border border-blue-500/30">
              {selectedSeverity}
            </span>
          )}
          {selectedYear && (
            <span className="px-3 py-1.5 rounded-full text-xs font-medium bg-purple-500/20 text-purple-400 border border-purple-500/30">
              {selectedYear}
            </span>
          )}
          {selectedVendor && (
            <span className="px-3 py-1.5 rounded-full text-xs font-medium bg-green-500/20 text-green-400 border border-green-500/30">
              {selectedVendor}
            </span>
          )}
        </div>
      </div>

      {showFilters && (
        <div className="p-4 bg-[#0d1117] border border-white/10 rounded-xl space-y-4 animate-fade-in-up">
          {/* Severity Filter */}
          <div>
            <label className="text-sm text-gray-400 mb-2 block">Severity</label>
            <div className="flex flex-wrap gap-2">
              {severities.map((severity) => (
                <button
                  key={severity}
                  onClick={() => onSeverityChange(selectedSeverity === severity ? null : severity)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                    selectedSeverity === severity
                      ? severity === 'CRITICAL' ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                        severity === 'HIGH' ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' :
                        severity === 'MEDIUM' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                        'bg-blue-500/20 text-blue-400 border-blue-500/30'
                      : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
                  }`}
                >
                  {severity}
                </button>
              ))}
            </div>
          </div>

          {/* Year Filter */}
          <div>
            <label className="text-sm text-gray-400 mb-2 block">Year</label>
            <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
              {years.sort((a, b) => b - a).map((year) => (
                <button
                  key={year}
                  onClick={() => onYearChange(selectedYear === year ? null : year)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                    selectedYear === year
                      ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                      : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
                  }`}
                >
                  {year}
                </button>
              ))}
            </div>
          </div>

          {/* Vendor Filter */}
          <div>
            <label className="text-sm text-gray-400 mb-2 block">Vendor</label>
            <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
              {vendors.sort().map((vendor) => (
                <button
                  key={vendor}
                  onClick={() => onVendorChange(selectedVendor === vendor ? null : vendor)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                    selectedVendor === vendor
                      ? 'bg-green-500/20 text-green-400 border-green-500/30'
                      : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10'
                  }`}
                >
                  {vendor}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
