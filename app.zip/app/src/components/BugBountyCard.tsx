import { Calendar, Target, DollarSign } from 'lucide-react';
import { SeverityBadge } from './SeverityBadge';
import type { BugBountyFinding } from '@/types/cve';

interface BugBountyCardProps {
  finding: BugBountyFinding;
}

export function BugBountyCard({ finding }: BugBountyCardProps) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      month: 'numeric', 
      day: 'numeric', 
      year: 'numeric' 
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="cve-card bg-[#0d1117] border border-white/10 rounded-xl p-5">
      <div className="flex items-start justify-between gap-4 mb-3">
        <h3 className="text-base font-semibold text-white leading-tight">{finding.title}</h3>
        <SeverityBadge severity={finding.severity} />
      </div>

      <p className="text-gray-400 text-sm line-clamp-2 mb-4">
        {finding.description}
      </p>

      <div className="flex items-center gap-4 text-sm mb-4">
        <div className="flex items-center gap-1.5 text-gray-400">
          <Target className="w-4 h-4" />
          <span>{finding.vulnerabilityType}</span>
        </div>
        <div className="flex items-center gap-1.5 text-gray-400">
          <Calendar className="w-4 h-4" />
          <span>{formatDate(finding.date)}</span>
        </div>
        <div className="flex items-center gap-1.5 text-blue-400 font-semibold">
          <DollarSign className="w-4 h-4" />
          <span>{formatCurrency(finding.bounty)}</span>
        </div>
      </div>

      <div className="flex items-center justify-between pt-3 border-t border-white/5">
        <span className="text-sm text-gray-500">{finding.program}</span>
        <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${
          finding.status === 'Resolved' ? 'status-resolved' :
          finding.status === 'Pending' ? 'status-pending' :
          'status-in-progress'
        }`}>
          {finding.status}
        </span>
      </div>
    </div>
  );
}
