import { useState, useMemo } from 'react';
import { SearchBar } from '@/components/SearchBar';
import { FilterBar } from '@/components/FilterBar';
import { CVECard } from '@/components/CVECard';
import { StatsCard } from '@/components/StatsCard';
import { CVEDetailModal } from '@/components/CVEDetailModal';
import { cveData, getCVEStats } from '@/data/cveData';
import type { CVE } from '@/types/cve';
import { Shield, AlertTriangle, AlertCircle, Info, Database } from 'lucide-react';

export function CVEDatabase() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState<string | null>(null);
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const [selectedVendor, setSelectedVendor] = useState<string | null>(null);
  const [selectedCVE, setSelectedCVE] = useState<CVE | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const stats = getCVEStats();

  // Get unique years and vendors
  const years = useMemo(() => {
    const yearSet = new Set<number>();
    cveData.forEach(cve => {
      yearSet.add(new Date(cve.publishedDate).getFullYear());
    });
    return Array.from(yearSet);
  }, []);

  const vendors = useMemo(() => {
    const vendorSet = new Set<string>();
    cveData.forEach(cve => vendorSet.add(cve.vendor));
    return Array.from(vendorSet);
  }, []);

  // Filter CVEs
  const filteredCVEs = useMemo(() => {
    return cveData.filter(cve => {
      const matchesSearch = !searchQuery || 
        cve.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cve.vendor.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cve.product.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cve.description.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesSeverity = !selectedSeverity || cve.severity === selectedSeverity;
      const matchesYear = !selectedYear || new Date(cve.publishedDate).getFullYear() === selectedYear;
      const matchesVendor = !selectedVendor || cve.vendor === selectedVendor;

      return matchesSearch && matchesSeverity && matchesYear && matchesVendor;
    }).sort((a, b) => new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime());
  }, [searchQuery, selectedSeverity, selectedYear, selectedVendor]);

  const handleCVEClick = (cve: CVE) => {
    setSelectedCVE(cve);
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Total CVEs" 
          value={stats.totalCVEs} 
          color="blue"
          subtitle="In database"
        />
        <StatsCard 
          title="Critical" 
          value={stats.criticalCount} 
          color="red"
          subtitle={`${((stats.criticalCount / stats.totalCVEs) * 100).toFixed(1)}% of total`}
        />
        <StatsCard 
          title="High Severity" 
          value={stats.highCount} 
          color="orange"
          subtitle={`${((stats.highCount / stats.totalCVEs) * 100).toFixed(1)}% of total`}
        />
        <StatsCard 
          title="Medium/Low" 
          value={stats.mediumCount + stats.lowCount} 
          color="green"
          subtitle="Lower risk vulnerabilities"
        />
      </div>

      {/* Severity Distribution */}
      <div className="bg-[#0d1117] border border-white/10 rounded-xl p-5">
        <h3 className="text-sm font-medium text-gray-400 mb-4">Severity Distribution</h3>
        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-2 px-4 py-2 bg-red-500/10 rounded-lg border border-red-500/20">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span className="text-sm text-red-400">Critical: {stats.criticalCount}</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-orange-500/10 rounded-lg border border-orange-500/20">
            <AlertTriangle className="w-4 h-4 text-orange-400" />
            <span className="text-sm text-orange-400">High: {stats.highCount}</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
            <AlertCircle className="w-4 h-4 text-yellow-400" />
            <span className="text-sm text-yellow-400">Medium: {stats.mediumCount}</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 bg-blue-500/10 rounded-lg border border-blue-500/20">
            <Info className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-blue-400">Low: {stats.lowCount}</span>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <SearchBar 
          value={searchQuery} 
          onChange={setSearchQuery}
          placeholder="Search CVE ID, vendor, product, or description..."
        />
        <FilterBar
          selectedSeverity={selectedSeverity}
          onSeverityChange={setSelectedSeverity}
          selectedYear={selectedYear}
          onYearChange={setSelectedYear}
          selectedVendor={selectedVendor}
          onVendorChange={setSelectedVendor}
          years={years}
          vendors={vendors}
        />
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <Database className="w-4 h-4" />
          <span>Showing {filteredCVEs.length} of {cveData.length} CVEs</span>
        </div>
        <div className="text-sm text-gray-500">
          1999 - 2025
        </div>
      </div>

      {/* CVE List */}
      <div className="grid gap-4">
        {filteredCVEs.map((cve, index) => (
          <div 
            key={cve.id} 
            className={`animate-fade-in-up stagger-${(index % 5) + 1}`}
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <CVECard cve={cve} onClick={() => handleCVEClick(cve)} />
          </div>
        ))}
      </div>

      {filteredCVEs.length === 0 && (
        <div className="text-center py-12">
          <Shield className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-400">No CVEs found</h3>
          <p className="text-sm text-gray-500 mt-1">Try adjusting your search or filters</p>
        </div>
      )}

      {/* Detail Modal */}
      <CVEDetailModal
        cve={selectedCVE}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedCVE(null);
        }}
      />
    </div>
  );
}
