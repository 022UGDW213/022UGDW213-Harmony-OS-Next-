import { BugBountyCard } from '@/components/BugBountyCard';
import { StatsCard } from '@/components/StatsCard';
import { bugBountyFindings, getBugBountyStats } from '@/data/cveData';
import { Trophy, DollarSign, Target } from 'lucide-react';

export function BugBounty() {
  const stats = getBugBountyStats();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0d1117] border border-white/10 rounded-xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-500/20 flex items-center justify-center flex-shrink-0">
            <Trophy className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white mb-1">Bug Bounty Projects</h2>
            <p className="text-gray-400 text-sm">
              Personal security research and vulnerability discoveries
            </p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Total Findings" 
          value={stats.totalFindings} 
          color="blue"
          subtitle="Vulnerabilities discovered"
        />
        <StatsCard 
          title="Resolved" 
          value={stats.resolved} 
          color="green"
          subtitle={`${((stats.resolved / stats.totalFindings) * 100).toFixed(0)}% resolution rate`}
        />
        <StatsCard 
          title="Critical" 
          value={stats.critical} 
          color="red"
          subtitle="High severity findings"
        />
        <StatsCard 
          title="Total Earned" 
          value={formatCurrency(stats.totalEarned)} 
          color="purple"
          subtitle="Cumulative bounties"
        />
      </div>

      {/* Findings List */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <Target className="w-5 h-5 text-blue-400" />
            Recent Findings
          </h3>
          <span className="text-sm text-gray-500">
            {stats.totalFindings} total
          </span>
        </div>

        <div className="grid gap-4">
          {bugBountyFindings.map((finding, index) => (
            <div 
              key={finding.id}
              className={`animate-fade-in-up stagger-${(index % 5) + 1}`}
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <BugBountyCard finding={finding} />
            </div>
          ))}
        </div>
      </div>

      {/* Summary */}
      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <DollarSign className="w-6 h-6 text-blue-400" />
          <h3 className="text-lg font-semibold text-white">Earnings Summary</h3>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-blue-400">
              {formatCurrency(stats.totalEarned)}
            </p>
            <p className="text-sm text-gray-400 mt-1">Total Earnings</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-green-400">
              {formatCurrency(stats.totalEarned / stats.totalFindings)}
            </p>
            <p className="text-sm text-gray-400 mt-1">Average Bounty</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-purple-400">
              {Math.max(...bugBountyFindings.map(f => f.bounty)).toLocaleString('en-US', {
                style: 'currency',
                currency: 'USD',
                maximumFractionDigits: 0
              })}
            </p>
            <p className="text-sm text-gray-400 mt-1">Highest Bounty</p>
          </div>
        </div>
      </div>
    </div>
  );
}
