// src/hooks/useEncryptedStorage.ts
import { useState, useEffect } from 'react';
import CryptoJS from 'crypto-js';

const STORAGE_KEY = 'encryptedSecrets';

export const useEncryptedStorage = (password: string | null) => {
  const [data, setData] = useState<Record<string, string> | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!password) {
      setData(null);
      setError(null);
      return;
    }

    try {
      const encrypted = localStorage.getItem(STORAGE_KEY);
      if (!encrypted) {
        setData({});
        return;
      }

      const bytes = CryptoJS.AES.decrypt(encrypted, password);
      const decrypted = bytes.toString(CryptoJS.enc.Utf8);
      if (!decrypted) throw new Error('Invalid password');
      
      setData(JSON.parse(decrypted));
      setError(null);
    } catch (err) {
      setError('Failed to decrypt. Wrong password?');
      setData(null);
    }
  }, [password]);

  const saveData = (newData: Record<string, string>) => {
    if (!password) throw new Error('Password required');
    const encrypted = CryptoJS.AES.encrypt(
      JSON.stringify(newData),
      password
    ).toString();
    localStorage.setItem(STORAGE_KEY, encrypted);
    setData(newData);
  };

  return { data, saveData, error };
};
