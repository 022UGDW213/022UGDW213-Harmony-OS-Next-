import { useState } from 'react';
import LockIcon from './components/icons/LockIcon';
import UnlockScreen from './components/UnlockScreen/UnlockScreen';
import { useEncryptedStorage } from './hooks/useEncryptedStorage';
