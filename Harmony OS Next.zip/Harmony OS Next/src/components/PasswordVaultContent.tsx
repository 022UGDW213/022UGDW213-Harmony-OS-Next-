// src/components/PasswordVaultContent.tsx
import { useState, useEffect } from 'react';
import CryptoJS from 'crypto-js';

interface SecretEntry {
  url: string;
  passkey: string;
}

const PasswordVaultContent = () => {
  const [masterPassword, setMasterPassword] = useState<string>('');
  const [unlocked, setUnlocked] = useState<boolean>(false);
  const [secrets, setSecrets] = useState<SecretEntry[]>([]);
  const [newEntry, setNewEntry] = (useState<{ url: string; passkey: string }>({ url: '', passkey: '' }));

  // Unlock and decrypt
  const unlockVault = () => {
    try {
      const encrypted = localStorage.getItem('harmony_vault');
      if (!encrypted) {
        setSecrets([]);
        setUnlocked(true);
        return;
      }
      const bytes = CryptoJS.AES.decrypt(encrypted, masterPassword);
      const decrypted = bytes.toString(CryptoJS.enc.Utf8);
      if (!decrypted) throw new Error('Invalid');
      setSecrets(JSON.parse(decrypted));
      setUnlocked(true);
    } catch (e) {
      alert('❌ Incorrect master password.');
    }
  };

  // Save encrypted data
  const saveSecrets = (updated: SecretEntry[]) => {
    const encrypted = CryptoJS.AES.encrypt(
      JSON.stringify(updated),
      masterPassword
    ).toString();
    localStorage.setItem('harmony_vault', encrypted);
    setSecrets(updated);
  };

  const addEntry = () => {
    if (!newEntry.url.trim() || !newEntry.passkey.trim()) return;
    saveSecrets([...secrets, { ...newEntry }]);
    setNewEntry({ url: '', passkey: '' });
  };

  const deleteEntry = (index: number) => {
    const updated = [...secrets];
    updated.splice(index, 1);
    saveSecrets(updated);
  };

  const lockVault = () => {
    setUnlocked(false);
    setMasterPassword('');
  };

  if (!unlocked) {
    return (
      <div className="p-5 text-white h-full flex flex-col justify-center">
        <h2 className="text-xl font-semibold mb-4 text-center">🔐 Password Vault</h2>
        <input
          type="password"
          value={masterPassword}
          onChange={(e) => setMasterPassword(e.target.value)}
          placeholder="Enter master password"
          className="w-full p-2.5 rounded bg-white/20 text-white mb-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          onKeyDown={(e) => e.key === 'Enter' && unlockVault()}
        />
        <button
          onClick={unlockVault}
          className="bg-blue-600 hover:bg-blue-700 py-2 rounded font-medium"
        >
          Unlock Vault
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 text-white h-full flex flex-col">
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-lg font-semibold">🔑 Password Vault</h2>
        <button
          onClick={lockVault}
          className="text-sm text-gray-300 hover:text-white"
        >
          🔒 Lock
        </button>
      </div>

      {/* Add new entry */}
      <div className="bg-white/10 p-3 rounded mb-4">
        <input
          value={newEntry.url}
          onChange={(e) => setNewEntry({ ...newEntry, url: e.target.value })}
          placeholder="URL"
          className="w-full p-1.5 mb-2 rounded bg-white/10 text-white text-sm"
        />
        <input
          value={newEntry.passkey}
          onChange={(e) => setNewEntry({ ...newEntry, passkey: e.target.value })}
          placeholder="Passkey"
          type="password"
          className="w-full p-1.5 rounded bg-white/10 text-white text-sm"
        />
        <button
          onClick={addEntry}
          className="mt-2 bg-green-600 hover:bg-green-700 text-xs px-2.5 py-1 rounded"
        >
          + Add
        </button>
      </div>

      {/* Secrets list */}
      <div className="flex-grow overflow-y-auto space-y-2">
        {secrets.map((entry, i) => (
          <div key={i} className="bg-white/10 p-2.5 rounded flex justify-between items-start">
            <div>
              <div className="font-mono text-sm truncate max-w-[200px]">{entry.url}</div>
              <div className="text-xs text-gray-300">●●●●●●</div>
            </div>
            <button
              onClick={() => deleteEntry(i)}
              className="text-red-400 hover:text-red-300 text-xs"
            >
              Delete
            </button>
          </div>
        ))}
        {secrets.length === 0 && (
          <p className="text-sm text-gray-400">No secrets saved yet.</p>
        )}
      </div>
    </div>
  );
};

export default PasswordVaultContent;
