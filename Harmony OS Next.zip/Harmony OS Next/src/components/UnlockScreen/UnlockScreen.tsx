// src/components/UnlockScreen/UnlockScreen.tsx
import { useState } from 'react';

interface UnlockScreenProps {
  onUnlock: (password: string) => void;
  error?: string;
}

export default function UnlockScreen({ onUnlock, error }: UnlockScreenProps) {
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.trim()) {
      onUnlock(password);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur flex items-center justify-center z-50">
      <form onSubmit={handleSubmit} className="bg-white/10 p-6 rounded-xl w-80 border border-white/20 shadow-2xl">
        <h2 className="text-xl font-semibold text-white text-center mb-4">🔐 Unlock Vault</h2>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter master password"
          className="w-full p-3 rounded bg-white/20 text-white placeholder:text-white/60 mb-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          autoFocus
        />
        {error && <p className="text-red-400 text-sm text-center mb-3">{error}</p>}
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 py-2.5 rounded-lg text-white font-medium transition-colors"
        >
          Unlock
        </button>
      </form>
    </div>
  );
}
